n= int(input("nhap nhiet do "))
if n>30:
    print("troi dang nong")
elif n<20:
    print("troi dang lanh")
else:
    print("thoi tiet de chiu")