mk1= int(input("nhap mat khau"))
mk2= int(input("xac nhan mat khau"))
if mk1== mk2:
    print("mat khau giong nhau roi")
else:
    print("mat khau khong giong nhau roi")