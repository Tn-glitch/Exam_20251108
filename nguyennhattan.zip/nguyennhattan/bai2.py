n= int(input("Nhap nam duong lich"))
if (n%4==0 and n%100==0) or n%400==0:
    print("n la nam nhuan")
else:
    print("n la nam khong nhuan")