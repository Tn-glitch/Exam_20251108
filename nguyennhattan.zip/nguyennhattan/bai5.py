km= float(input(" Nhap km cua xe taxi"))
if km<1:
    tong_tien= km * 7000
elif 1<km< 5:
    tong_tien= 7000 + (km-1) * 6500
else:
    tong_tien= 7000 + 4 * 6500 + (km-5) * 6000
print(f"tong tien phai tra la: {tong_tien:.0f}dong")