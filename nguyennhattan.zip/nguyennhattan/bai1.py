x1= int(input("nhap so nguyen x1"))
x2= int(input("nhap so nguyen x2"))
x3= int(input("nhap so nguyen x3"))
if x1<x2 or x1<x3:
    print("x1 la so nho nhat")
elif x2<x3:
    print("x2 la so nho nhat")
else:
    print("x3 la so nho nhat")